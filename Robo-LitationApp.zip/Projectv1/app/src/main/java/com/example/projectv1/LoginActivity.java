package com.example.projectv1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.SwitchCompat;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    AppCompatButton loginBtn,googleBtn,facebookBtn;
    SwitchCompat switchBtn;
    EditText email,pass;
    TextView forgot,switchText;
    ImageView upperImg;
    FirebaseAuth auth;
    String profileType="";
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+([a-z]|[a-z]\\.[a-z])+";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        auth = FirebaseAuth.getInstance();

        loginBtn = (AppCompatButton) findViewById(R.id.button3);
        googleBtn = (AppCompatButton) findViewById(R.id.googlebtn);
        facebookBtn = (AppCompatButton) findViewById(R.id.facebookbtn);
        email = (EditText) findViewById(R.id.editTextTextPersonName);
        pass = (EditText) findViewById(R.id.editTextTextPersonName2);
        forgot = (TextView) findViewById(R.id.textView6);
        switchBtn = (SwitchCompat) findViewById(R.id.switchCompat);
        switchText = (TextView) findViewById(R.id.textView9);
        upperImg = (ImageView) findViewById(R.id.imageView);

        try{
            profileType = getIntent().getStringExtra("profileType");
            if(TextUtils.isEmpty(profileType))
            {
                profileType="Patient";
            }
        }
        catch (Exception e)
        {

        }

        changeColor(profileType);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                String profileType = switchText.getText().toString();
                String emailID = email.getText().toString().trim();
                String password = pass.getText().toString().trim();

                if((TextUtils.isEmpty(emailID))) {
                    email.setError("Enter Email Address");
                } else if((TextUtils.isEmpty(password))) {
                    pass.setError("Enter Password");
                } else if(!emailID.matches(emailPattern)) {
                    email.setError("Enter in Proper Email Format");
                } else if(password.length()<6) {
                    pass.setError("Enter More than 6 Characters");
                } else {
                    auth.signInWithEmailAndPassword(emailID, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()) {
                                try{
                                    Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                                    intent.putExtra("profileType", profileType);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);
                                    finish();
                                } catch(Exception e) {
                                    Toast.makeText(LoginActivity.this, "Error: "+e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                            else {
                                Toast.makeText(LoginActivity.this, "Error: Credentials Not Found", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
        googleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LoginActivity.this,"Google Login feature is unavailable",Toast.LENGTH_SHORT).show();
            }
        });
        facebookBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LoginActivity.this,"Facebook Login feature is unavailable",Toast.LENGTH_SHORT).show();
            }
        });
        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LoginActivity.this,"Forgot Password feature is unavailable",Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void changeColor(String profile) {
        if(profile.equals("Physiotherapist"))
        {
//            switchText.setText("Physiotherapist");
            profileType = "Physiotherapist";
            upperImg.setBackgroundResource(R.drawable.bgupperorange);
            loginBtn.setBackgroundResource(R.drawable.button_background_orange);
        }
        else if(profile.equals("Patient"))
        {
//            switchText.setText("Patient");
            profileType = "Patient";
            upperImg.setBackgroundResource(R.drawable.bgupperpurple);
            loginBtn.setBackgroundResource(R.drawable.button_background_purple);
        }
    }
}