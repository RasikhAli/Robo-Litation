package com.example.projectv1;

public class AboutusClass {
    String About;
    String Dev;
    String Email;
    String ImageLoc;
    String Name;
    String Speciality;

    public AboutusClass() {
    }

    public AboutusClass(String About, String Dev, String Email, String ImageLoc, String Name, String Speciality) {
        this.About = About;
        this.Dev = Dev;
        this.Email = Email;
        this.ImageLoc = ImageLoc;
        this.Name = Name;
        this.Speciality = Speciality;
    }

    public String getAbout() {
        return About;
    }

    public String getDev() {
        return Dev;
    }

    public String getEmail() {
        return Email;
    }

    public String getImageLoc() {
        return ImageLoc;
    }

    public String getName() {
        return Name;
    }

    public String getSpeciality() {
        return Speciality;
    }

    public void setAbout(String about) {
        About = about;
    }

    public void setDev(String dev) {
        Dev = dev;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public void setImageLoc(String imageLoc) {
        ImageLoc = imageLoc;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setSpeciality(String speciality) {
        Speciality = speciality;
    }
}
