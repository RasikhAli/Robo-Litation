package com.example.projectv1;

class HandExClass {
    int HoldRelease;
    int Sets;
    int Days;
    String ImageLoc;
    String TotalTime;
    String ExerciseName;

    public HandExClass() {
    }

    public HandExClass(int holdRelease, int sets, int days, String imageLoc, String totalTime, String exerciseName) {
        HoldRelease = holdRelease;
        Sets = sets;
        Days = days;
        ImageLoc = imageLoc;
        TotalTime = totalTime;
        ExerciseName = exerciseName;
    }

    public int getHoldRelease() {
        return HoldRelease;
    }

    public void setHoldRelease(int holdRelease) {
        HoldRelease = holdRelease;
    }

    public int getSets() {
        return Sets;
    }

    public void setSets(int sets) {
        Sets = sets;
    }

    public int getDays() {
        return Days;
    }

    public void setDays(int days) {
        Days = days;
    }

    public String getImageLoc() {
        return ImageLoc;
    }

    public void setImageLoc(String imageLoc) {
        ImageLoc = imageLoc;
    }

    public String getTotalTime() {
        return TotalTime;
    }

    public void setTotalTime(String totalTime) {
        TotalTime = totalTime;
    }

    public String getExerciseName() {
        return ExerciseName;
    }

    public void setExerciseName(String exerciseName) {
        ExerciseName = exerciseName;
    }

}
