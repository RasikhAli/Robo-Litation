package com.example.projectv1;

import androidx.annotation.GravityInt;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.saadahmedsoft.popupdialog.PopupDialog;
import com.saadahmedsoft.popupdialog.Styles;
import com.saadahmedsoft.popupdialog.listener.OnDialogButtonClickListener;

import de.hdodenhof.circleimageview.CircleImageView;

public class DashboardActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    FloatingActionButton floatingActionButton;
    DrawerLayout drawerLayout;
    BottomNavigationView bottomNavigationView;
    DatabaseReference dbr;
    Toolbar toolbar;
    NavigationView navigationView;
    FirebaseAuth auth;

    String profiletype, ptype, fullName, imageLoc;
    View header;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        auth = FirebaseAuth.getInstance();
        if(auth.getCurrentUser()==null) {
            Intent intent = new Intent(DashboardActivity.this, MainActivity.class);
            startActivity(intent);
        }

        String profile = "";
        try{
            profile = getIntent().getStringExtra("profileType");
            if(TextUtils.isEmpty(profile)) {
                profile="Patient";
            }
        } catch (Exception e) {
        }

        String userid = auth.getCurrentUser().getUid();
        for(int i=0;i<2;i++){
            if(i==0){
                profile="Patient";
            }
            else if(i==1){
                profile="Physiotherapist";
            }
            dbr = FirebaseDatabase.getInstance().getReference()
                    .child("Users")
                    .child(profile)
                    .child(userid)
                    .child("profileType");
            dbr.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    profiletype = snapshot.getValue(String.class);
                    if (profiletype != null) {
                        if(profiletype.equals("Physiotherapist") || profiletype.equals("Patient")) {
                            ptype = profiletype;
                            setColors(profiletype);
                            getVals(userid,ptype);
                        }
                    } else {
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }

        floatingActionButton = (FloatingActionButton) findViewById(R.id.fab);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigationView);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.bringToFront();

        ActionBarDrawerToggle drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();

        getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new HomeFragment()).commit();

        if (savedInstanceState == null){
            MenuItem menuItem = navigationView.getMenu().getItem(0).setChecked(true);
            onNavigationItemSelected(menuItem);
        }

        bottomNavigationView.setBackground(null);
        bottomNavigationView.setOnItemSelectedListener(item -> {

            switch (item.getItemId()) {
                case R.id.home:
                    replaceFragment(new HomeFragment());
                    break;
                case R.id.profiles:
                    replaceFragment(new ProfileFragment());
                    break;
                case R.id.report:
                    replaceFragment(new ReportFragment());
                    break;
                case R.id.exercises:
                    replaceFragment(new ExercisesFragment());
                    break;
            }

            return true;
        });

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBottomDialog();
            }
        });

    }

    private void getVals(String userid, String ptype) {
        FirebaseDatabase.getInstance().getReference().child("Users").child(ptype).child(userid).child("fullName").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                fullName = snapshot.getValue(String.class);
                FirebaseDatabase.getInstance().getReference().child("Users").child(ptype).child(userid).child("profilePic").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        imageLoc = snapshot.getValue(String.class);
                        setHeaderVal(fullName,imageLoc);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void setHeaderVal(String fullName, String imageLoc) {
        header = navigationView.getHeaderView(0);
        CircleImageView circleImageView = (CircleImageView) header.findViewById(R.id.profilePic);
        TextView textName = (TextView) header.findViewById(R.id.userName);
        TextView textType = (TextView) header.findViewById(R.id.userType);

        textName.setText(fullName);
        textType.setText(ptype);
        Glide.with(header.getContext()).load(imageLoc).fitCenter().into(circleImageView);
    }

    private void setColors(String profileType) {
        if(profileType.equals("Patient")) {
            toolbar.setBackgroundResource(R.color.lavender);
        } else {
            toolbar.setBackgroundResource(R.color.orange);
        }
    }

    private  void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.addToBackStack(null).commit();
    }

    private void showBottomDialog() {

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.bottom_sheet_layout);

        LinearLayout conHand = dialog.findViewById(R.id.layoutCHand);
        LinearLayout conArm = dialog.findViewById(R.id.layoutCArm);
        LinearLayout conLeg = dialog.findViewById(R.id.layoutCLeg);
        ImageView cancelButton = dialog.findViewById(R.id.cancelButton);

        conHand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Toast.makeText(DashboardActivity.this,"Connect to Hand is clicked",Toast.LENGTH_SHORT).show();
            }
        });
        conArm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Toast.makeText(DashboardActivity.this,"Connect to Arm is clicked",Toast.LENGTH_SHORT).show();
            }
        });
        conLeg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Toast.makeText(DashboardActivity.this,"Connect to Leg is clicked",Toast.LENGTH_SHORT).show();
            }
        });
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        dialog.getWindow().setGravity(Gravity.BOTTOM);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new HomeFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_settings:
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new SettingsFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_about:
                getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new AboutFragment()).addToBackStack(null).commit();
                break;
            case R.id.nav_logout:
                PopupDialog dialog = PopupDialog.getInstance(DashboardActivity.this);
                dialog.setStyle(Styles.ANDROID_DEFAULT)
                        .setHeading("Logout")
                        .setDescription("Are you sure you want to logout?"+
                                " This action cannot be undone")
                        .setCancelable(false)
                        .showDialog(new OnDialogButtonClickListener() {
                            @Override
                            public void onPositiveClicked(Dialog dialog) {
                                FirebaseAuth.getInstance().signOut();
                                Intent intent = new Intent(DashboardActivity.this, LoginActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();
                                super.onPositiveClicked(dialog);
                            }
                            @Override
                            public void onNegativeClicked(Dialog dialog) {
                                super.onNegativeClicked(dialog);
                            }
                        });
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }
}