package com.example.projectv1;

import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import de.hdodenhof.circleimageview.CircleImageView;

public class SettingsFragment extends Fragment {

    EditText upName, upEmail, upPhone;
    CircleImageView upImg;
    AppCompatButton saveButton;
    FirebaseAuth auth;
    DatabaseReference database;
    FirebaseStorage storage;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+([a-z]|[a-z]\\.[a-z])+";
    Uri imageUri;
    FirebaseUser user;
    String uid, fname, email, phone, image, profileType="";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_settings, container, false);

        upName = (EditText) v.findViewById(R.id.uploadName);
        upEmail = (EditText) v.findViewById(R.id.uploadEmail);
        upPhone = (EditText) v.findViewById(R.id.uploadPhone);
        upImg = (CircleImageView) v.findViewById(R.id.uploadImg);
        saveButton = (AppCompatButton) v.findViewById(R.id.saveBtn);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance().getReference();
        storage = FirebaseStorage.getInstance();
        user = auth.getCurrentUser();
        assert user != null;
        uid = user.getUid();

        for(int i=0;i<2;i++) {
            String profile = "";
            if(i==0){
                profile="Patient";
            }
            else{
                profile="Physiotherapist";
            }
            DatabaseReference dbr = database.child("Users").child(profile).child(uid);
            dbr.addValueEventListener(new ValueEventListener() {

                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.exists()) {
                        fname = snapshot.child("fullName").getValue().toString();
                        email = snapshot.child("email").getValue().toString();
                        phone = snapshot.child("phoneNumber").getValue().toString();
                        image = snapshot.child("profilePic").getValue().toString();
                        profileType = snapshot.child("profileType").getValue().toString();

                        upName.setText(fname);
                        upEmail.setText(email);
                        upPhone.setText(phone);
                        Glide.with(getActivity()).load(image).into(upImg);

                        if(profileType.equals("Patient")) {
                            v.findViewById(R.id.settingLayout1).setBackgroundResource(R.drawable.settings_border_purple);
//                            v.findViewById(R.id.textView11).setBackgroundColor(R.color.lavender);
                            v.findViewById(R.id.uploadName).setBackgroundResource(R.drawable.settings_border_purple);
                            v.findViewById(R.id.uploadEmail).setBackgroundResource(R.drawable.settings_border_purple);
                            v.findViewById(R.id.uploadPhone).setBackgroundResource(R.drawable.settings_border_purple);
                            v.findViewById(R.id.saveBtn).setBackgroundResource(R.drawable.button_background_purple);
                        } else {
                            v.findViewById(R.id.settingLayout1).setBackgroundResource(R.drawable.settings_border_orange);
//                            v.findViewById(R.id.textView11).setBackgroundResource(R.color.orange);
                            v.findViewById(R.id.uploadName).setBackgroundResource(R.drawable.settings_border_orange);
                            v.findViewById(R.id.uploadEmail).setBackgroundResource(R.drawable.settings_border_orange);
                            v.findViewById(R.id.uploadPhone).setBackgroundResource(R.drawable.settings_border_orange);
                            v.findViewById(R.id.saveBtn).setBackgroundResource(R.drawable.button_background_orange);
                        }
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isNameChanged() || isEmailChanged() || isPhoneChanged()) {
                    Toast.makeText(getActivity(), "Success: Saved", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getActivity(), "Error: No Changes in Data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return v;
    }
    public boolean isNameChanged(){
        String updateName = upName.getText().toString().trim();
        if(!updateName.isEmpty() && !updateName.equals(fname)){
            database.child("Users").child(profileType).child(uid).child("fullName").setValue(updateName);
            return true;
        }else{
            return false;
        }
    }
    public boolean isEmailChanged(){
        String updateEmail = upEmail.getText().toString().trim();
        if(!updateEmail.isEmpty() && !updateEmail.equals(email)){
            database.child("Users").child(profileType).child(uid).child("email").setValue(updateEmail);
            return true;
        }else{
            return false;
        }
    }
    public boolean isPhoneChanged(){
        String updatePhone = upPhone.getText().toString().trim();
        if(!updatePhone.isEmpty() && !updatePhone.equals(phone)){
            database.child("Users").child(profileType).child(uid).child("phoneNumber").setValue(updatePhone);
            return true;
        }else{
            return false;
        }
    }
}