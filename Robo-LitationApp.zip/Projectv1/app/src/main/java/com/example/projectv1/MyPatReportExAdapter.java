package com.example.projectv1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MyPatReportExAdapter extends RecyclerView.Adapter<MyPatReportExAdapter.MyReportExHolder> {
    ArrayList<Users> data;
    Context context;

    public MyPatReportExAdapter(Context context, ArrayList<Users> userSource) {
        this.context = context;
        this.data = userSource;
    }

    @NonNull
    @Override
    public MyPatReportExAdapter.MyReportExHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.report_patient_item,parent,false);
        return new MyPatReportExAdapter.MyReportExHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyPatReportExAdapter.MyReportExHolder holder, int position) {
        Users user = data.get(position);
        holder.exPName.setText(user.getFullName());
        holder.exPEmail.setText(user.getEmail());
        holder.exPNum.setText(user.getPhoneNumber());

        String userID = user.getId();

        DatabaseReference databaseReference1 = FirebaseDatabase.getInstance().getReference("Reports");
        holder.exPatRepRv.setLayoutManager(new LinearLayoutManager(context));
        ArrayList<HandExReportClass> dataSource = new ArrayList<>();
        MyReportExAdapter myReportExAdapter = new MyReportExAdapter(context,dataSource);
        holder.exPatRepRv.setAdapter(myReportExAdapter);
        databaseReference1.child(userID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                        HandExReportClass handEx = childSnapshot.getValue(HandExReportClass.class);
                        dataSource.add(handEx);
                    }
                    myReportExAdapter.notifyDataSetChanged();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyReportExHolder extends RecyclerView.ViewHolder{
        TextView exPName, exPEmail, exPNum;
        RecyclerView exPatRepRv;

        public MyReportExHolder(@NonNull View itemView) {
            super(itemView);
            exPatRepRv = itemView.findViewById(R.id.exPatRepRv);
            exPName = itemView.findViewById(R.id.exPatName);
            exPEmail = itemView.findViewById(R.id.exPatEmail);
            exPNum = itemView.findViewById(R.id.exPatNum);
        }
    }
}