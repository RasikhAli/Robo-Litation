package com.example.projectv1;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.angads25.toggle.interfaces.OnToggledListener;
import com.github.angads25.toggle.model.ToggleableView;
import com.github.angads25.toggle.widget.LabeledSwitch;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sigma.niceswitch.NiceSwitch;
import com.sigma.niceswitch.NiceSwitchRound;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeFragment extends Fragment {

    private final int REQUEST_ENABLE_BT = 101;

    FirebaseAuth auth;
    DatabaseReference dbr;
    DatabaseReference firebaseDatabase;
    String profile = "", name = "", profileType = "", image = "";

    TextView perName, perType, bluText, devText;
    CircleImageView prof;
    AppCompatButton btn;
    LabeledSwitch blBtn;
    View view;
    BluetoothAdapter bluetoothAdapter;
    BluetoothDevice connectedDevice;
    Set<BluetoothDevice> pairedDevices;

    private ListView listViewDevices;
    DeviceListAdapter adapter;
    private ArrayList<BluetoothDevice> deviceList;

    @SuppressLint("MissingPermission")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);

        perName = (TextView) v.findViewById(R.id.perName);
        perType = (TextView) v.findViewById(R.id.perType);
        bluText = (TextView) v.findViewById(R.id.bluetoothText);
        devText = (TextView) v.findViewById(R.id.deviceText);
        prof = (CircleImageView) v.findViewById(R.id.profPic);
        btn = (AppCompatButton) v.findViewById(R.id.profBtn);
        view = (View) v.findViewById(R.id.view3);
        blBtn = v.findViewById(R.id.bluetoothSwitch);
        listViewDevices = v.findViewById(R.id.listViewDevices);

        deviceList = new ArrayList<>();
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        auth = FirebaseAuth.getInstance();
        String userid = auth.getCurrentUser().getUid();
        firebaseDatabase = FirebaseDatabase.getInstance().getReference();

        adapter = new DeviceListAdapter(getActivity(), R.layout.bluetooth_devices, deviceList);
        listViewDevices.setAdapter(adapter);

        if (bluetoothAdapter.isEnabled()) {
            blBtn.setOn(true); // Enables Bluetooth
            bluText.setText("Enabled");

            pairedDevices = bluetoothAdapter.getBondedDevices();
            for (BluetoothDevice device : pairedDevices) {
                if (device.getBondState() == BluetoothDevice.BOND_BONDED) {
                    String deviceName = device.getName();
                    String deviceAddress = device.getAddress();
                    connectedDevice = bluetoothAdapter.getRemoteDevice(deviceAddress);
                    devText.setText(connectedDevice.getName()); // Display the device name in a TextView

                    deviceList.add(device);
                    break;
                }
            }

            bluetoothAdapter.startDiscovery();
            IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            getActivity().registerReceiver(receiver, filter);
        }

        for (int i = 0; i < 2; i++) {
            String profile = "";
            if (i == 0) {
                profile = "Patient";
            } else {
                profile = "Physiotherapist";
            }
            dbr = firebaseDatabase.child("Users").child(profile).child(userid);
            dbr.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        name = snapshot.child("fullName").getValue().toString();
                        image = snapshot.child("profilePic").getValue().toString();
                        profileType = snapshot.child("profileType").getValue().toString();

                        if (profileType.equals("Physiotherapist")) {
                            view.setBackgroundResource(R.drawable.background_top_ora);
                        }
                        perName.setText(name);
                        perType.setText(profileType);
                        Glide.with(getActivity()).load(image).into(prof);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProfileFragment fragmentB = new ProfileFragment();
                (getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragmentB).addToBackStack(null).commit();
            }
        });

        blBtn.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    if (!bluetoothAdapter.isEnabled()) {
                        Intent enableBluetoothIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivityForResult(enableBluetoothIntent, REQUEST_ENABLE_BT);
                        bluText.setText("Enabled");
                        pairedDevices = bluetoothAdapter.getBondedDevices();
                        for (BluetoothDevice device : pairedDevices) {
                            if (device.getBondState() == BluetoothDevice.BOND_BONDED) {
                                String deviceName = device.getName();
                                String deviceAddress = device.getAddress();
                                ;
                                connectedDevice = bluetoothAdapter.getRemoteDevice(deviceAddress);
                                devText.setText(connectedDevice.getName()); // Display the device name in a TextView
//                                devText.setText(deviceName); // Display the device name in a TextView
                                break;
                            }
                        }

                        bluetoothAdapter.startDiscovery();
                        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                        getActivity().registerReceiver(receiver, filter);
                    }
                    bluetoothAdapter.enable(); // Enables Bluetooth
                } else {
                    if (bluetoothAdapter.isEnabled()) {
                        bluetoothAdapter.disable();// Disables Bluetooth
                        bluText.setText("Disabled");
                        devText.setText("Not-Connected");
                    }
                }
            }
        });

        return v;
    }

    private class DeviceListAdapter extends ArrayAdapter<BluetoothDevice> {
        private LayoutInflater layoutInflater;

        public DeviceListAdapter(Context context, int resource, List<BluetoothDevice> objects) {
            super(context, resource, objects);
            layoutInflater = LayoutInflater.from(context);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.bluetooth_devices, parent, false);
            }

            BluetoothDevice device = getItem(position);
            TextView textViewDeviceNum = convertView.findViewById(R.id.textViewDeviceNum);
            TextView textViewDeviceName = convertView.findViewById(R.id.textViewDeviceName);
            TextView textViewDeviceAddress = convertView.findViewById(R.id.textViewDeviceAddress);
            if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                Intent enableBluetoothIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBluetoothIntent, REQUEST_ENABLE_BT);
            }
            textViewDeviceNum.setText((position+1)+".");
            textViewDeviceName.setText(device.getName());
            textViewDeviceAddress.setText(device.getAddress());

            return convertView;
        }
    }

    // Create a BroadcastReceiver for ACTION_FOUND.
    final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            // When discovery finds a device
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Get the BluetoothDevice object from the Intent
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (!deviceList.contains(device)) {
                    deviceList.add(device);
                }
                adapter.notifyDataSetChanged();
            }
        }
    };

}
