package com.example.projectv1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileFragment extends Fragment {

    CircleImageView imageView;
    TextView name, email, mobile, password;
    AppCompatButton edit;

    DatabaseReference database;
    FirebaseStorage storage;
    FirebaseAuth auth;
    FirebaseUser user;

    String uid, fname, emailE, phone, image, pass, profileType;
    View vi;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_profile, container, false);

        vi = (View) v.findViewById(R.id.view2);
        imageView = (CircleImageView) v.findViewById(R.id.profileView);
        name = (TextView) v.findViewById(R.id.nameView);
        email = (TextView) v.findViewById(R.id.viewEmail);
        mobile = (TextView) v.findViewById(R.id.viewNumber);
        password = (TextView) v.findViewById(R.id.viewPass);
        edit = (AppCompatButton) v.findViewById(R.id.editBtn);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance().getReference();
        storage = FirebaseStorage.getInstance();
        user = auth.getCurrentUser();
        assert user != null;
        uid = user.getUid();

        for(int i=0;i<2;i++) {
            String profile = "";
            if(i==0){
                profile="Patient";
            }
            else{
                profile="Physiotherapist";
            }
            DatabaseReference dbr = database.child("Users").child(profile).child(uid);
            dbr.addValueEventListener(new ValueEventListener() {

                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.exists()) {
                        fname = snapshot.child("fullName").getValue().toString();
                        emailE = snapshot.child("email").getValue().toString();
                        phone = snapshot.child("phoneNumber").getValue().toString();
                        image = snapshot.child("profilePic").getValue().toString();
                        pass = snapshot.child("password").getValue().toString();
                        profileType = snapshot.child("profileType").getValue().toString();

                        if(profileType.equals("Physiotherapist")){
                            vi.setBackgroundResource(R.drawable.background_top_ora);
                        }

                        name.setText(fname);
                        email.setText(emailE);
                        mobile.setText(phone);
                        password.setText(pass);
                        Glide.with(getActivity()).load(image).into(imageView);
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SettingsFragment fragmentB = new SettingsFragment();
                (getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragmentB).addToBackStack(null).commit();
            }
        });

        return v;
    }
}