package com.example.projectv1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.SwitchCompat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import de.hdodenhof.circleimageview.CircleImageView;

public class SignupActivity extends AppCompatActivity {

    EditText fName, eMail, Pass1, PhoneNum;
    AppCompatButton signUpBtn;
    SwitchCompat switchBtn;
    TextView switchText;
    ImageView upperImg;
    CircleImageView profileImg;
    FirebaseAuth auth;
    FirebaseDatabase database;
    FirebaseStorage storage;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+([a-z]|[a-z]\\.[a-z])+";
    Uri imageUri;
    String imageString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

        fName = (EditText) findViewById(R.id.fname);
        eMail = (EditText) findViewById(R.id.email);
        Pass1 = (EditText) findViewById(R.id.pass1);
        PhoneNum = (EditText) findViewById(R.id.phone);
        signUpBtn = (AppCompatButton) findViewById(R.id.signup);
        switchBtn = (SwitchCompat) findViewById(R.id.switchCompat);
        switchText = (TextView) findViewById(R.id.textView7);
        upperImg = (ImageView) findViewById(R.id.imageView);
        profileImg = (CircleImageView) findViewById(R.id.profile_image);

        signUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                String fullName = fName.getText().toString().trim();
                String email = eMail.getText().toString().trim();
                String pass1 = Pass1.getText().toString().trim();
                String phoneNum = PhoneNum.getText().toString().trim();
                String profileType = switchText.getText().toString().trim();

                fName.setError(null);
                eMail.setError(null);
                Pass1.setError(null);
                PhoneNum.setError(null);
                if(fullName.isEmpty())
                {
                    fName.setError("Enter Full Name");
                }
                else if(email.isEmpty())
                {
                    eMail.setError("Enter Email Address");
                }
                else if(pass1.isEmpty())
                {
                    Pass1.setError("Enter Password (at-least 6 characters)");
                }
                else if(phoneNum.isEmpty() || phoneNum.length()<11)
                {
                    PhoneNum.setError("Enter Phone Number (11 Digits)");
                }
                else if(!email.matches(emailPattern))
                {
                    eMail.setError("Enter in Proper Email Format");
                }
                else if(pass1.length()<6)
                {
                    Pass1.setError("Enter More than 6 Characters");
                }
                else
                {
                    fName.clearFocus();
                    eMail.clearFocus();
                    Pass1.clearFocus();
                    PhoneNum.clearFocus();

                    auth.createUserWithEmailAndPassword(email,pass1).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()) {
                                String id = task.getResult().getUser().getUid();
                                DatabaseReference reference = database.getReference().child("Users").child(profileType).child(id);
                                StorageReference storageReference = storage.getReference().child("ProfilePic").child(profileType).child(id);

                                if(imageUri!=null) {
                                    storageReference.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                                            if(task.isSuccessful()) {
                                                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                    @Override
                                                    public void onSuccess(Uri uri) {
                                                        imageString = uri.toString();
                                                        Users users = new Users(id,imageString,fullName,email,pass1,phoneNum,profileType);
                                                        reference.setValue(users).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                if(task.isSuccessful()) {
                                                                    Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                                                                    intent.putExtra("profileType", profileType);
                                                                    startActivity(intent);
                                                                    finish();
                                                                }
                                                                else{
                                                                    Toast.makeText(SignupActivity.this, "Error: Failed to Create User", Toast.LENGTH_SHORT).show();
                                                                }
                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }
                                else{
                                    imageString = "https://firebasestorage.googleapis.com/v0/b/projectv1-c231e.appspot.com/o/defaultPic.jpg?alt=media&token=88c6789e-451d-4b55-aef2-d164198d3945";
                                    Users users = new Users(id,imageString,fullName,email,pass1,phoneNum,profileType);
                                    reference.setValue(users).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()) {
                                                Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                                                intent.putExtra("profileType", profileType);
                                                startActivity(intent);
                                                finish();
                                            }
                                            else{
                                                Toast.makeText(SignupActivity.this, "Error: Failed to Create User", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }
                            }
                            else{
                                Toast.makeText(SignupActivity.this, "Error: "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

//                    Toast.makeText(SignupActivity.this, fullName+' '+email+' '+pass1+' '+phoneNum+' '+profileType, Toast.LENGTH_SHORT).show();
                }
            }
        });

        switchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(switchBtn.isChecked() == true)
                {
                    switchText.setText("Physiotherapist");
                    upperImg.setBackgroundResource(R.drawable.bgupperorange);
                    signUpBtn.setBackgroundResource(R.drawable.button_background_orange);
                }
                else if(switchBtn.isChecked() == false)
                {
                    switchText.setText("Patient");
                    upperImg.setBackgroundResource(R.drawable.bgupperpurple);
                    signUpBtn.setBackgroundResource(R.drawable.button_background_purple);
                }
            }
        });

        profileImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Select Picture"),10);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==10)
        {
            if(data!=null)
            {
                imageUri = data.getData();
                profileImg.setImageURI(imageUri);
            }
        }
    }
}