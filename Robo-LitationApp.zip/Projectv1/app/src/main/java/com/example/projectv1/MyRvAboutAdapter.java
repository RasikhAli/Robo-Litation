package com.example.projectv1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MyRvAboutAdapter extends RecyclerView.Adapter<MyRvAboutAdapter.MyAboutHolder> {
    ArrayList<AboutusClass> data;
    Context context;

    public MyRvAboutAdapter(Context context, ArrayList<AboutusClass> dataGet) {
        this.context = context;
        this.data = dataGet;
    }

    @NonNull
    @Override
    public MyAboutHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.about_item,parent,false);
        return new MyAboutHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAboutHolder holder, int position) {
        AboutusClass user = data.get(position);
        holder.personDev.setText(user.Name);
        holder.personSpeciality.setText(user.Speciality);
        holder.personAbout.setText(user.About);
        holder.personEmail.setText(user.Email);
        holder.personHandle.setText(user.Dev);
        Glide.with(context).load(user.ImageLoc).into(holder.personImg);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyAboutHolder extends RecyclerView.ViewHolder{
        CircleImageView personImg;
        TextView personDev, personSpeciality, personAbout, personHandle, personEmail;

        public MyAboutHolder(@NonNull View itemView) {
            super(itemView);
            personImg = itemView.findViewById(R.id.recImg);
            personDev = itemView.findViewById(R.id.recDeveloper);
            personSpeciality = itemView.findViewById(R.id.recSpeciality);
            personAbout = itemView.findViewById(R.id.recAbout);
            personHandle = itemView.findViewById(R.id.recHandle);
            personEmail = itemView.findViewById(R.id.recEmail);
        }
    }
}


