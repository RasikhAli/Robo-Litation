package com.example.projectv1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyReportExAdapter extends RecyclerView.Adapter<MyReportExAdapter.MyReportExHolder> {
    ArrayList<HandExReportClass> data;
    Context context;

    public MyReportExAdapter(Context context, ArrayList<HandExReportClass> dataGet) {
        this.context = context;
        this.data = dataGet;
    }

    @NonNull
    @Override
    public MyReportExAdapter.MyReportExHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.report_items,parent,false);
        return new MyReportExAdapter.MyReportExHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyReportExAdapter.MyReportExHolder holder, int position) {
        HandExReportClass handEx = data.get(position);
        holder.exPName.setText(handEx.getName());
        holder.exTot.setText(handEx.getTotalDays()+" Days");
        holder.exComp.setText(handEx.getCompletedDays()+" Days");
        holder.exP.setProgress(Integer.parseInt(handEx.getCompletedDays()));
        holder.exP.setMax(handEx.getTotalDays());
    }


    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyReportExHolder extends RecyclerView.ViewHolder{
        TextView exPName, exComp, exTot;
        ProgressBar exP;

        public MyReportExHolder(@NonNull View itemView) {
            super(itemView);
            exPName = itemView.findViewById(R.id.exProgName);
            exComp = itemView.findViewById(R.id.exCompDays);
            exTot = itemView.findViewById(R.id.exTotDays);
            exP = itemView.findViewById(R.id.exProg);
        }
    }
}