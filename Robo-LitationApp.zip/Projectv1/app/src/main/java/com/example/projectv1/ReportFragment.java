package com.example.projectv1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ReportFragment extends Fragment {

    RecyclerView recyclerView;
    ArrayList<HandExReportClass> dataSource;
    ArrayList<Users> userSource;
    MyPatReportExAdapter myPatReportExAdapter;
    MyReportExAdapter myReportExAdapter;
    DatabaseReference databaseReference,databaseReference1, databaseReference2;
    String uid, profileType="";
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_report, container, false);

        recyclerView = v.findViewById(R.id.exProgRev);
        view = v.findViewById(R.id.view3);

        uid=FirebaseAuth.getInstance().getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child("Physiotherapist");
        databaseReference.child(uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    profileType="Physiotherapist";
                    view.setBackgroundResource(R.drawable.background_top_ora);
                    databaseReference1 = FirebaseDatabase.getInstance().getReference("Reports");
                    recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                    userSource = new ArrayList<>();
                    myPatReportExAdapter = new MyPatReportExAdapter(getActivity(),userSource);
                    recyclerView.setAdapter(myPatReportExAdapter);
                    databaseReference1.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.exists()){
                                for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                                    String userID = childSnapshot.getKey().toString();
                                    databaseReference2 = FirebaseDatabase.getInstance().getReference("Users").child("Patient").child(userID);
                                    databaseReference2.addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            if(snapshot.exists()){
                                                Users user = snapshot.getValue(Users.class);
                                                userSource.add(user);
                                                myPatReportExAdapter.notifyDataSetChanged();
                                            }

                                        }
                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });
                                }
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                } else{
                    databaseReference1 = FirebaseDatabase.getInstance().getReference("Reports");
                    recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                    dataSource = new ArrayList<>();
                    myReportExAdapter = new MyReportExAdapter(getActivity(),dataSource);
                    recyclerView.setAdapter(myReportExAdapter);

                    databaseReference1.child(uid).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.exists()){
                                for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                                    HandExReportClass handEx = childSnapshot.getValue(HandExReportClass.class);
                                    dataSource.add(handEx);
                                }
                                myReportExAdapter.notifyDataSetChanged();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        return v;
    }
}