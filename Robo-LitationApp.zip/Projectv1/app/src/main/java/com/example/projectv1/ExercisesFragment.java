package com.example.projectv1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ExercisesFragment extends Fragment {

    RecyclerView recyclerView;
    ArrayList<HandExClass> dataSource;
    MyRvHandExAdapter myRvHandExAdapter;
    DatabaseReference databaseReference;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_exercises, container, false);
        recyclerView = v.findViewById(R.id.handexRv);
        databaseReference = FirebaseDatabase.getInstance().getReference("ExercisesHand");
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        dataSource = new ArrayList<>();
        myRvHandExAdapter = new MyRvHandExAdapter(getActivity(),dataSource);
        recyclerView.setAdapter(myRvHandExAdapter);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot datasnapshot: snapshot.getChildren()){
                    HandExClass handex = datasnapshot.getValue(HandExClass.class);
                    dataSource.add(handex);
                }
                myRvHandExAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        return v;
    }
}