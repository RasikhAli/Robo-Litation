package com.example.projectv1;

import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;
import com.saadahmedsoft.popupdialog.PopupDialog;
import com.saadahmedsoft.popupdialog.Styles;
import com.saadahmedsoft.popupdialog.listener.OnDialogButtonClickListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class exerciseDetails extends Fragment {
    String exName, exImage;
    int exSets;
    int exHoldRelease;
    int FullDays;
    int i=0;
    int counter=0;
    int pos;

    TextView exerName, exerRepeat, progTextH, progTextN;
    ImageView exerImage;
    AppCompatButton exerBtn;
    CircularProgressBar circularProgressBar;

    String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    String PrevD = "", CompDays = "0";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_exercisedetails, container, false);

        exName = getArguments().getString("exName");
        exImage = getArguments().getString("exImage");
        exSets = getArguments().getInt("exSets");
        exHoldRelease = getArguments().getInt("exHoldRelease");
        FullDays = getArguments().getInt("exDays");
        pos = getArguments().getInt("position");

        exerName = v.findViewById(R.id.exerciseName);
        exerRepeat = v.findViewById(R.id.exerciseRepeat);
        progTextH = v.findViewById(R.id.progressTextHead);
        progTextN = v.findViewById(R.id.progressText);
        exerImage = v.findViewById(R.id.exerciseImage);
        exerBtn = v.findViewById(R.id.startBtn);
        circularProgressBar = v.findViewById(R.id.circularProgressBar);

        exerName.setText(exName);
        exerRepeat.setText("Perform "+String.valueOf(exSets)+" Times");
        progTextN.setText(String.valueOf(exHoldRelease));
        Glide.with(getActivity()).load(exImage).into(exerImage);

        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        String uid = firebaseAuth.getUid();

        exerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exerBtn.setClickable(false);
                exerBtn.setText("In Progress");
                CountDownTimer mCountDownTimer1;
                mCountDownTimer1=new CountDownTimer((exSets*(exHoldRelease))*1000,exHoldRelease*1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        if(exSets!=0){
                            exSets = exSets-1;
                            exerRepeat.setText("Perform "+String.valueOf(exSets)+" Times");
                            counter=1;
                            circularProgressBar.setProgressMax(exHoldRelease);
                            CountDownTimer mCountDownTimer;
                            mCountDownTimer=new CountDownTimer(exHoldRelease*1000,1000) {
                                @Override
                                public void onTick(long millisUntilFinished) {
                                    i++;
                                    progTextN.setText(String.valueOf(exHoldRelease-i));
                                    circularProgressBar.setProgress(i);
                                }
                                @Override
                                public void onFinish() {
                                    i=0;
                                    progTextN.setText(String.valueOf(exHoldRelease));
                                    circularProgressBar.setProgress(0);
                                    counter--;
                                    if(progTextH.getText().equals("Hold")){
                                        progTextH.setText("Release");
                                    }else{
                                        progTextH.setText("Hold");
                                    }
                                }
                            };
                            mCountDownTimer.start();
                        }
                    }
                    @Override
                    public void onFinish() {
//                        Toast.makeText(getActivity(), "Exercise is Complete", Toast.LENGTH_SHORT).show();
                        PopupDialog dialog = PopupDialog.getInstance(getActivity());
                        dialog.setStyle(Styles.SUCCESS)
                                .setHeading("Well Done")
                                .setDescription("You have successfully"+
                                        " completed the Exercise")
                                .setCancelable(false)
                                .showDialog(new OnDialogButtonClickListener() {
                                    @Override
                                    public void onDismissClicked(Dialog dialog) {
                                        super.onDismissClicked(dialog);
                                    }
                                });
                        exSets=getArguments().getInt("exSets");
                        exerRepeat.setText("Perform "+String.valueOf(exSets)+" Times");
                        exerBtn.setClickable(true);
                        exerBtn.setText("Start");

                        DatabaseReference databaseReference1 = FirebaseDatabase.getInstance().getReference().child("Reports").child(uid).child(exName);
                        databaseReference1.child("Name").setValue(exName);
                        databaseReference1.child("Date").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.exists()){
                                    PrevD = snapshot.getValue(String.class);
                                    if(!date.equals(PrevD))
                                    {
                                        DatabaseReference databaseReference2 = FirebaseDatabase.getInstance().getReference().child("Reports").child(uid).child(exName);
                                        databaseReference2.child("CompletedDays").addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot2) {
                                                if(snapshot2.exists()) {
                                                    CompDays = snapshot2.getValue().toString();
                                                    if(Integer.valueOf(CompDays) < FullDays){
                                                        CompDays = String.valueOf(Integer.valueOf(CompDays)+1);
                                                        databaseReference2.child("CompletedDays").setValue(CompDays);
                                                        databaseReference2.child("TotalDays").setValue(FullDays);
                                                    }
                                                }
                                                else{
                                                    CompDays = String.valueOf(Integer.valueOf(CompDays)+1);
                                                    databaseReference2.child("CompletedDays").setValue(CompDays);
                                                    databaseReference2.child("TotalDays").setValue(FullDays);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                        databaseReference1.child("Date").setValue(date);
                                    }
                                }
                                else{
                                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Reports").child(uid).child(exName);
                                    databaseReference.child("CompletedDays").addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot2) {
                                            if(snapshot2.exists()) {
                                                CompDays = snapshot2.getValue().toString();
                                                if(Integer.valueOf(CompDays) < FullDays){
                                                    CompDays = String.valueOf(Integer.valueOf(CompDays)+1);
                                                    databaseReference.child("CompletedDays").setValue(CompDays);
                                                    databaseReference.child("TotalDays").setValue(FullDays);
                                                }
                                            }
                                            else{
                                                CompDays = String.valueOf(Integer.valueOf(CompDays)+1);
                                                databaseReference.child("CompletedDays").setValue(CompDays);
                                                databaseReference.child("TotalDays").setValue(FullDays);
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });
                                    databaseReference1.child("Date").setValue(date);
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
                };
                mCountDownTimer1.start();
            }
        });

        return v;
    }

}