package com.example.projectv1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;


public class MyRvHandExAdapter extends RecyclerView.Adapter<MyRvHandExAdapter.MyHandExHolder> {
    ArrayList<HandExClass> data;
    Context context;

    public MyRvHandExAdapter(Context context, ArrayList<HandExClass> dataGet) {
        this.context = context;
        this.data = dataGet;
    }

    @NonNull
    @Override
    public MyRvHandExAdapter.MyHandExHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.handex_item,parent,false);
        return new MyRvHandExAdapter.MyHandExHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyRvHandExAdapter.MyHandExHolder holder, int position) {
        HandExClass handex = data.get(position);
        holder.exName.setText("Exercise: "+handex.getExerciseName());
        holder.exRepeat.setText("Repeat "+String.valueOf(handex.getSets())+" Times");
        holder.exHold.setText(String.valueOf(handex.getHoldRelease())+"Sec Hold");
        holder.exRelease.setText(String.valueOf(handex.getHoldRelease())+"Sec Release");
        int pos = position;
        Glide.with(context).load(handex.getImageLoc()).into(holder.exImage);

        holder.exBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toExerciseDetails(handex.getExerciseName(), handex.getSets(), handex.getImageLoc(), handex.getHoldRelease(), handex.getDays(), pos);
            }
        });
    }

    private void toExerciseDetails(String exerciseName, int sets, String imageLoc, int holdRelease, int days, int position) {
        Bundle bundle = new Bundle();
        bundle.putString("exName", exerciseName);
        bundle.putInt("exSets", sets);
        bundle.putString("exImage", imageLoc);
        bundle.putInt("exHoldRelease", holdRelease);
        bundle.putInt("exDays", days);
        bundle.putInt("position", position);

        exerciseDetails fragmentB = new exerciseDetails();
        fragmentB.setArguments(bundle);
        ((AppCompatActivity)context).getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragmentB).addToBackStack(null).commit();
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyHandExHolder extends RecyclerView.ViewHolder{
        ImageView exImage;
        TextView exName, exRepeat, exHold, exRelease, exBtn;

        public MyHandExHolder(@NonNull View itemView) {
            super(itemView);
            exImage = itemView.findViewById(R.id.handExImg);
            exName = itemView.findViewById(R.id.handExName);
            exRepeat = itemView.findViewById(R.id.handExRepeat);
            exHold = itemView.findViewById(R.id.handExHold);
            exRelease = itemView.findViewById(R.id.handExRelease);
            exBtn = itemView.findViewById(R.id.handExStartButton);
        }
    }
}