package com.example.projectv1;

public class HandExReportClass {
    String Name;
    String CompletedDays;
    String Date;
    int TotalDays;

    public HandExReportClass() {
    }

    public HandExReportClass(String name, String completedDays, String date, int totalDays) {
        Name = name;
        CompletedDays = completedDays;
        Date = date;
        TotalDays = totalDays;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getCompletedDays() {
        return CompletedDays;
    }

    public void setCompletedDays(String completedDays) {
        CompletedDays = completedDays;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public int getTotalDays() {
        return TotalDays;
    }

    public void setTotalDays(int totalDays) {
        TotalDays = totalDays;
    }
}
